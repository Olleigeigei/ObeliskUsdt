package comm

import "github.com/assimon/luuu/controller"

var Ctrl = &BaseCommController{}

type BaseCommController struct {
	controller.BaseController
}
