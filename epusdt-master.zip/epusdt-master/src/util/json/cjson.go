package json

import jsoniter "github.com/json-iterator/go"

var Cjson = jsoniter.ConfigCompatibleWithStandardLibrary
